import { Card } from '@/components/ui/card'
import { GroupResponse } from '@/service/api'
import { useTranslation } from 'react-i18next'
import { Button } from '@/components/ui/button'
import { useRemoveGroup } from '@/service/api'
import { toast } from 'sonner'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { useState } from 'react'
import { MoreVertical, Pencil, Power, PowerOff, Trash2 } from 'lucide-react'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'
import useDirDetection from '@/hooks/use-dir-detection'
import { queryClient } from '@/utils/query-client'
import type { ReactNode } from 'react'

interface GroupProps {
  group: GroupResponse
  onEdit: (group: GroupResponse) => void
  onToggleStatus: (group: GroupResponse) => Promise<void>
  selectionControl?: ReactNode
  selected?: boolean
}

const DeleteAlertDialog = ({ group, isOpen, onClose, onConfirm }: { group: GroupResponse; isOpen: boolean; onClose: () => void; onConfirm: () => void }) => {
  const { t } = useTranslation()
  const dir = useDirDetection()

  return (
    <AlertDialog open={isOpen} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{t('group.deleteConfirmation')}</AlertDialogTitle>
          <AlertDialogDescription>
            <span dir={dir} dangerouslySetInnerHTML={{ __html: t('group.deleteConfirm', { name: group.name }) }} />
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onClose}>{t('cancel')}</AlertDialogCancel>
          <AlertDialogAction variant="destructive" onClick={onConfirm}>
            {t('delete')}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

export default function Group({ group, onEdit, onToggleStatus, selectionControl, selected = false }: GroupProps) {
  const { t } = useTranslation()
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const deleteGroupMutation = useRemoveGroup()

  const handleDeleteClick = (event: Event) => {
    event.preventDefault()
    event.stopPropagation()
    setShowDeleteDialog(true)
  }

  const handleConfirmDelete = async () => {
    try {
      await deleteGroupMutation.mutateAsync({ groupId: group.id })
      toast.success(t('success', { defaultValue: 'Success' }), {
        description: t('group.deleteSuccess', {
          name: group.name,
          defaultValue: 'Group "{name}" has been deleted successfully',
        }),
      })
      setShowDeleteDialog(false)
      queryClient.invalidateQueries({ queryKey: ['/api/groups'] })
    } catch (error) {
      toast.error(t('error', { defaultValue: 'Error' }), {
        description: t('group.deleteFailed', {
          name: group.name,
          defaultValue: 'Failed to delete group "{name}"',
        }),
      })
    }
  }

  return (
    <>
      <Card className={cn('group relative cursor-pointer px-4 py-5 transition-colors hover:bg-accent', selected && 'border-primary/50 bg-accent/30')} onClick={() => onEdit(group)}>
        <div className="flex items-start gap-3">
          {selectionControl ? <div className="pt-1">{selectionControl}</div> : null}
          <div className="flex min-w-0 flex-1 items-start gap-3">
            <div className="min-w-0 flex-1">
              <div className="flex min-w-0 items-center gap-2">
                <div className={cn('min-h-2 min-w-2 flex-shrink-0 rounded-full', group.is_disabled ? 'bg-red-500' : 'bg-green-500')} />
                <div className="flex min-w-0 flex-1 items-center gap-2">
                  <div className="min-w-0 truncate font-medium">{group.name}</div>
                  <div className="flex-shrink-0 font-mono text-xs text-muted-foreground">({group.inbound_tags?.length || 0})</div>
                </div>
              </div>
              <div className="min-w-0 truncate text-sm text-muted-foreground">
                {t('admins.total.users')}: {group.total_users || 0}
              </div>
            </div>
            <div onClick={e => e.stopPropagation()}>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button type="button" variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onSelect={e => {
                      e.stopPropagation()
                      onToggleStatus(group)
                    }}
                  >
                    {group.is_disabled ? <Power className="mr-2 h-4 w-4" /> : <PowerOff className="mr-2 h-4 w-4" />}
                    {group.is_disabled ? t('enable') : t('disable')}
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onSelect={e => {
                      e.stopPropagation()
                      onEdit(group)
                    }}
                  >
                    <Pencil className="mr-2 h-4 w-4" />
                    {t('edit')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={handleDeleteClick} className="text-destructive">
                    <Trash2 className="mr-2 h-4 w-4" />
                    {t('delete')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </Card>

      <DeleteAlertDialog group={group} isOpen={showDeleteDialog} onClose={() => setShowDeleteDialog(false)} onConfirm={handleConfirmDelete} />
    </>
  )
}
