import asyncio
from datetime import datetime as dt
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, Query, Request, status
from PasarGuardNodeBridge import NodeAPIError
from sse_starlette.sse import EventSourceResponse

from app.db import AsyncSession, get_db
from app.db.models import NodeStatus
from app.models.admin import AdminDetails
from app.models.node import (
    BulkNodesActionResponse,
    BulkNodeSelection,
    NodeCoreUpdate,
    NodeCreate,
    NodeGeoFilesUpdate,
    NodeModify,
    NodeResponse,
    NodeSettings,
    NodesResponse,
    NodesSimpleResponse,
    RemoveNodesResponse,
    UsageTable,
    UserIPList,
    UserIPListAll,
)
from app.models.stats import NodeRealtimeStats, NodeStatsList, NodeUsageStatsList, Period
from app.operation import OperatorType
from app.operation.node import NodeOperation
from app.utils import responses
from app.nats.node_rpc import node_nats_client
from config import ROLE

from .authentication import check_sudo_admin

node_operator = NodeOperation(operator_type=OperatorType.API)
router = APIRouter(tags=["Node"], prefix="/api/node", responses={401: responses._401, 403: responses._403})


async def _node_logs_local(node_id: int, request: Request) -> EventSourceResponse:
    context_manager = await node_operator.get_logs(node_id=node_id)

    async def event_generator() -> AsyncGenerator[str, None]:
        try:
            async with context_manager() as log_queue:
                while True:
                    if await request.is_disconnected():
                        break

                    item = await log_queue.get()
                    # Check if we received an error
                    if isinstance(item, NodeAPIError):
                        raise item
                    # Process the log message
                    yield f"{item}"
        except asyncio.CancelledError:
            pass
        except Exception as e:
            yield f"Error retrieving logs: {str(e)}\n"

    return EventSourceResponse(event_generator())


async def _node_logs_remote(node_id: int, request: Request) -> EventSourceResponse:
    async def event_generator() -> AsyncGenerator[str, None]:
        sub = None
        stop_subject = None
        nc = await node_nats_client.get_client()
        if not nc:
            yield "Error retrieving logs: NATS not available\n"
            return

        try:
            stream_info = await node_nats_client.request("start_logs", {"node_id": node_id})
            subject = stream_info.get("subject")
            stop_subject = stream_info.get("stop_subject")
            if not subject or not stop_subject:
                yield "Error retrieving logs: invalid stream response\n"
                return

            sub = await nc.subscribe(subject)

            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await sub.next_msg(timeout=1)
                except asyncio.TimeoutError:
                    continue
                yield msg.data.decode()
        except asyncio.CancelledError:
            pass
        except Exception as e:
            yield f"Error retrieving logs: {str(e)}\n"
        finally:
            if stop_subject:
                try:
                    await nc.publish(stop_subject, b"stop")
                except Exception:
                    pass
            if sub:
                try:
                    await sub.unsubscribe()
                except Exception:
                    pass

    return EventSourceResponse(event_generator())


_node_logs_handler = _node_logs_local if ROLE.runs_node else _node_logs_remote


@router.get("/settings", response_model=NodeSettings)
async def get_node_settings(_: AdminDetails = Depends(check_sudo_admin)):
    """Retrieve the current node settings."""
    return NodeSettings()


@router.get("/usage", response_model=NodeUsageStatsList)
async def get_usage(
    db: AsyncSession = Depends(get_db),
    start: dt | None = Query(None, examples=["2024-01-01T00:00:00+03:30"]),
    end: dt | None = Query(None, examples=["2024-01-31T23:59:59+03:30"]),
    period: Period = Period.hour,
    node_id: int | None = None,
    group_by_node: bool = False,
    _: AdminDetails = Depends(check_sudo_admin),
):
    """Retrieve usage statistics for nodes within a specified date range."""
    return await node_operator.get_usage(
        db=db, start=start, end=end, period=period, node_id=node_id, group_by_node=group_by_node
    )


@router.get("s", response_model=NodesResponse)
async def get_nodes(
    core_id: int | None = None,
    offset: int | None = None,
    limit: int | None = None,
    status: list[NodeStatus] | None = Query(None),
    enabled: bool = False,
    ids: list[int] | None = Query(None),
    search: str | None = None,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    """Retrieve a list of all nodes. Accessible only to sudo admins."""

    return await node_operator.get_db_nodes(
        db=db,
        core_id=core_id,
        offset=offset,
        limit=limit,
        status=status,
        enabled=enabled,
        ids=ids,
        search=search,
    )


@router.get(
    "s/simple",
    response_model=NodesSimpleResponse,
    summary="Get lightweight node list",
    description="Returns only id and name for nodes. Optimized for dropdowns and autocomplete.",
)
async def get_nodes_simple(
    offset: int | None = None,
    limit: int | None = None,
    search: str | None = None,
    sort: str | None = None,
    all: bool = False,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    """Get lightweight node list with only id and name"""
    return await node_operator.get_nodes_simple(
        db=db,
        offset=offset,
        limit=limit,
        search=search,
        sort=sort,
        all=all,
    )


@router.post("s/reconnect")
async def reconnect_all_node(
    core_id: int | None = None,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """
    Trigger reconnection for all nodes or a specific core.
    """
    await node_operator.restart_all_node(db=db, admin=admin, core_id=core_id)
    return {}


@router.post(
    "",
    response_model=NodeResponse,
    responses={409: responses._409},
    status_code=status.HTTP_201_CREATED,
)
async def create_node(
    new_node: NodeCreate, db: AsyncSession = Depends(get_db), admin: AdminDetails = Depends(check_sudo_admin)
):
    """Create a new node to the database."""
    return await node_operator.create_node(db, new_node, admin)


@router.get("/{node_id}", response_model=NodeResponse)
async def get_node(node_id: int, db: AsyncSession = Depends(get_db), _: AdminDetails = Depends(check_sudo_admin)):
    """Retrieve details of a specific node by its ID."""
    return await node_operator.get_validated_node(db=db, node_id=node_id)


@router.post("/{node_id}/update")
async def update_node(node_id: int, db: AsyncSession = Depends(get_db), _: AdminDetails = Depends(check_sudo_admin)):
    return await node_operator.update_node(db=db, node_id=node_id)


@router.post("/{node_id}/core_update")
async def update_core(
    node_id: int,
    node_core_update: NodeCoreUpdate,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    return await node_operator.update_core(db=db, node_id=node_id, node_core_update=node_core_update)


@router.post("/{node_id}/geofiles")
async def update_geofiles(
    node_id: int,
    node_geofiles_update: NodeGeoFilesUpdate,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    return await node_operator.update_geofiles(db=db, node_id=node_id, node_geofiles_update=node_geofiles_update)


@router.put("/{node_id}", response_model=NodeResponse)
async def modify_node(
    modified_node: NodeModify,
    node_id: int,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Modify a node's details. Only accessible to sudo admins."""
    return await node_operator.modify_node(db, node_id=node_id, modified_node=modified_node, admin=admin)


@router.post("/{node_id}/reset", response_model=NodeResponse)
async def reset_node_usage(
    node_id: int, db: AsyncSession = Depends(get_db), admin: AdminDetails = Depends(check_sudo_admin)
):
    """
    Reset node traffic usage (uplink and downlink).
    Creates a log entry in node_usage_reset_logs table.
    Only accessible to sudo admins.
    """
    return await node_operator.reset_node_usage(db, node_id=node_id, admin=admin)


@router.post("/{node_id}/reconnect")
async def reconnect_node(
    node_id: int, db: AsyncSession = Depends(get_db), admin: AdminDetails = Depends(check_sudo_admin)
):
    """Trigger a reconnection for the specified node. Only accessible to sudo admins."""
    await node_operator.restart_node(db, node_id, admin)
    return {}


@router.put("/{node_id}/sync")
async def sync_node(
    node_id: int,
    flush_users: bool = False,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    return await node_operator.sync_node_users(db, node_id=node_id, flush_users=flush_users)


@router.delete("/{node_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_node(
    node_id: int, db: AsyncSession = Depends(get_db), admin: AdminDetails = Depends(check_sudo_admin)
):
    """Remove a node and remove it from xray in the background."""
    await node_operator.remove_node(db=db, node_id=node_id, admin=admin)
    return {}


@router.get("/{node_id}/logs")
async def node_logs(node_id: int, request: Request, _: AdminDetails = Depends(check_sudo_admin)):
    """
    Stream logs for a specific node as Server-Sent Events.
    """
    return await _node_logs_handler(node_id, request)


@router.get("/{node_id}/stats", response_model=NodeStatsList)
async def get_node_stats_periodic(
    node_id: int,
    start: dt | None = Query(None, examples=["2024-01-01T00:00:00+03:30"]),
    end: dt | None = Query(None, examples=["2024-01-31T23:59:59+03:30"]),
    period: Period = Period.hour,
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    return await node_operator.get_node_stats_periodic(db, node_id=node_id, start=start, end=end, period=period)


@router.get("/{node_id}/realtime_stats", response_model=NodeRealtimeStats)
async def realtime_node_stats(node_id: int, _: AdminDetails = Depends(check_sudo_admin)):
    """Retrieve node real-time statistics."""
    return await node_operator.get_node_system_stats(node_id=node_id)


@router.get("s/realtime_stats", response_model=dict[int, NodeRealtimeStats | None])
async def realtime_nodes_stats(_: AdminDetails = Depends(check_sudo_admin)):
    """Retrieve nodes real-time statistics."""
    return await node_operator.get_nodes_system_stats()


@router.get("/online_stats/{username}/ip", response_model=UserIPListAll)
async def user_online_ip_list_all_nodes(
    username: str, db: AsyncSession = Depends(get_db), _: AdminDetails = Depends(check_sudo_admin)
):
    """Retrieve user ips from all nodes."""
    return await node_operator.get_user_ip_list_all_nodes(db=db, username=username)


@router.get("/{node_id}/online_stats/{username}", response_model=dict[int, int])
async def user_online_stats(
    node_id: int, username: str, db: AsyncSession = Depends(get_db), _: AdminDetails = Depends(check_sudo_admin)
):
    """Retrieve user online stats by node."""
    return await node_operator.get_user_online_stats_by_node(db=db, node_id=node_id, username=username)


@router.get("/{node_id}/online_stats/{username}/ip", response_model=UserIPList)
async def user_online_ip_list(
    node_id: int, username: str, db: AsyncSession = Depends(get_db), _: AdminDetails = Depends(check_sudo_admin)
):
    """Retrieve user ips by node."""
    return await node_operator.get_user_ip_list_by_node(db=db, node_id=node_id, username=username)


@router.delete(
    "s/clear_usage_data/{table}",
    summary="Clear usage data from a specified table",
)
async def clear_usage_data(
    table: UsageTable,
    start: dt | None = Query(None),
    end: dt | None = Query(None),
    db: AsyncSession = Depends(get_db),
    _: AdminDetails = Depends(check_sudo_admin),
):
    """
    Deletes **all rows** from the selected usage data table. Use with caution.

    Allowed tables:
        - `node_user_usages`: Deletes user-specific node usage traffic records.
        - `node_usages`: Deletes node-level aggregated traffic (uplink/downlink) records.

    **Optional filters:**
        - `start`: ISO 8601 timestamp to filter from (inclusive)
        - `end`: ISO 8601 timestamp to filter to (exclusive)

    ⚠️ This operation is irreversible. Ensure correct usage in production environments.
    """
    return await node_operator.clear_usage_data(db, table, start, end)


@router.post(
    "s/bulk/delete",
    response_model=RemoveNodesResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_delete_nodes(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Delete selected nodes by ID."""
    return await node_operator.bulk_remove_nodes(db, bulk_nodes, admin)


@router.post(
    "s/bulk/disable",
    response_model=BulkNodesActionResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_disable_nodes(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Disable selected nodes by ID."""
    return await node_operator.bulk_set_nodes_status(db, bulk_nodes, admin, status=NodeStatus.disabled)


@router.post(
    "s/bulk/enable",
    response_model=BulkNodesActionResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_enable_nodes(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Enable selected nodes by ID."""
    return await node_operator.bulk_set_nodes_status(db, bulk_nodes, admin, status=NodeStatus.connected)


@router.post(
    "s/bulk/reset",
    response_model=BulkNodesActionResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_reset_nodes_usage(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Reset usage for selected nodes by ID."""
    return await node_operator.bulk_reset_nodes_usage(db, bulk_nodes, admin)


@router.post(
    "s/bulk/reconnect",
    response_model=BulkNodesActionResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_reconnect_nodes(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Reconnect selected nodes by ID."""
    return await node_operator.bulk_restart_nodes(db, bulk_nodes, admin)


@router.post(
    "s/bulk/update",
    response_model=BulkNodesActionResponse,
    responses={400: responses._400, 403: responses._403, 404: responses._404},
)
async def bulk_update_nodes(
    bulk_nodes: BulkNodeSelection,
    db: AsyncSession = Depends(get_db),
    admin: AdminDetails = Depends(check_sudo_admin),
):
    """Update selected nodes by ID."""
    return await node_operator.bulk_update_nodes(db, bulk_nodes, admin)
